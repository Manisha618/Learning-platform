let questions=  [
                    {  num:1,
	                   question:"What is the difference between is and ==?",
	                   answer:"B) is checks memory, == checks value",
	                   options:[
	                   	       "A) is checks value, == checks memory",
	 	                       "B) is checks memory, == checks value",
	 	                       "C) Both check memory",   
	 	                       "D) Both check value"
	 	                   ]
	                },

                    {   num:2,
	                    question:"Why do we use self in class methods?",
	                    answer:"b) It refers to the instance of the  class",
	                    options:["a) It refers to the class",
                                 "b) It refers to the instance of the  class",
                                 "c) It refers to a global variable",
                                 "d) It stores temporary data"]
                    },

	                {   num:3,
	                    question:" What will print(bool([])) return?",
	                    answer:"b) False",
	                    options:["a) True",
                                 "b) False",
                                 "c) Error",
                                 "d) None"]
                    },

	                {   num:4,
	                    question:"How does Python manage memory for variables?",
	                    answer:"a) Uses Stack and Heap memory",
	                    options:[
	                    	    "a) Uses Stack and Heap memory",
                                "b) Uses only Heap memory",
                                "c) Uses only Stack memory",
                                "d) No memory allocation"]
	                },

	                {   num:5,
	                    question:"What is the purpose of _init_ in a class?",
	                    answer:"a) Initializes an instance of a class",
	                    options:["a) Initializes an instance of a class",
                                 "b) Destroys an instance of a class",
                                "c) Defines a static method",
                                "d) Runs at the end of the program"]
	                 }                    
];


console.log("question.js file loaded successfully :",questions);