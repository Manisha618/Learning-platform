let questions=  [
                    {  num:1,
	                   question:"Which of the following is the correct syntax to declare a variable in C?",
	                   answer:"A) int num;",
	                   options:[
	                   	       "A) int num;",
	 	                       "B) num int;",
	 	                       "C) variable num;",   
	 	                       "D) int: num;"
	 	                   ]
	                },

                    {   num:2,
	                    question:" Which keyword is used to define a constant variable in C?",
	                    answer:"c) const",
	                    options:["a) static",
                                 "b) constant",
                                 "c) const",
                                 "d) define"]
                    },

	                {   num:3,
	                    question:" What is the output of printf('%d', 10 + 5);?",
	                    answer:"b) 15",
	                    options:["a) 10+5",
                                 "b) 15",
                                 "c) 105",
                                 "d) Error"]
                    },

	                {   num:4,
	                    question:"Which loop is guaranteed to execute at least once?",
	                    answer:"c) do-while loop",
	                    options:[
	                    	    "a) for loop",
                                "b) while loop",
                                "c) do-while loop",
                                "d) None of the above"]
	                },

	                {   num:5,
	                    question:"What is the correct way to declare a pointer variable in C?",
	                    answer:"a) int *ptr;",
	                    options:["a) int *ptr;",
                                 "b) int ptr*;",
                                "c) *int ptr;",
                                "d) ptr int*;"]
	                 }                    
];


console.log("question.js file loaded successfully :",questions);