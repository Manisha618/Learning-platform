let questions=  [
                    {  num:1,
	                   question:"What does HTML stand for?",
	                   answer:"B) Hyper Text Markup Language",
	                   options:[
	                   	       "A)Hyper Transfer Markup Language",
	 	                       "B) Hyper Text Markup Language",
	 	                       "C)High-Level Text Markup Language",   
	 	                       "D)Hyperlink and Text Management Language"
	 	                   ]
	                },

                    {   num:2,
	                    question:"which attribute links label to input?",
	                    answer:"a)for",
	                    options:["a)for",
                                 "b)id",
                                 "c) name",
                                 "d) target"]
                    },

	                {   num:3,
	                    question:"How can you create a hyperlink that opens in a new tab?",
	                    answer:"b) Use the target attribute with _blank",
	                    options:["a) Use the target attribute with _self",
                                 "b) Use the target attribute with _blank",
                                 "c) Use the newtab attribute",
                                 "d) Use the href attribute with _new "]
                    },

	                {   num:4,
	                    question:"What is the correct way to add a comment in HTML?",
	                    answer:"d) none of the above",
	                    options:[
	                    	    "a) // This is a comment",
                                "b) /* This is a comment */",
                                "c) ** This is a comment **",
                                "d) none of the above"]
	                },

	                {   num:5,
	                    question:"How can you embed a YouTube video into an HTML page?",
	                    answer:"b) Using the iframe tag",
	                    options:["a) Using the video tag ",
                                 "b) Using the iframe tag",
                                "c) Using the embed tag",
                                "d) Using the source tag "]
	                 }                    
];


console.log("question.js file loaded successfully :",questions);