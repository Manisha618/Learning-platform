let questions=  [
                    {  num:1,
	                   question:"What does CSS stand for?",
	                   answer:"B) Cascading Style Sheets",
	                   options:[
	                   	       "A) Creative Style Sheets",
	 	                       "B) Cascading Style Sheets",
	 	                       "C) Computer Style Sheets",   
	 	                       "D) Colorful Style Sheets"
	 	                   ]
	                },

                    {   num:2,
	                    question:"Which CSS property is used to change text color?",
	                    answer:"C) color",
	                    options:["A) font-color",
                                 "B) text-style",
                                 "C) color",
                                 "D) text-color"]
                    },

	                {   num:3,
	                    question:" Which CSS property is used to change the background color?",
	                    answer:"A) background-color",
	                    options:["A) background-color",
                                 "B) color",
                                 "C) bg-color",
                                 "D) bgcolor"]
                    },

	                {   num:4,
	                    question:"How do you make text bold in CSS?",
	                    answer:"A) font-weight: bold;",
	                    options:[
	                    	    "A) font-weight: bold;",
                                "B) text-style: bold",
                                "C) bold: true;",
                                "D) font-bold: yes;"]
	                },

	                {   num:5,
	                    question:"What is the default position value of an HTML element?",
	                    answer:"D) relative",
	                    options:["A) fixed ",
                                 "B) absolute",
                                "C) static",
                                "D) relative"]
	                 }                    
];


console.log("question.js file loaded successfully :",questions);