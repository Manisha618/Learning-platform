let questions=  [
                    {  num:1,
	                   question:"Which variable type is block-scoped?",
	                   answer:"D) Both b and c ",
	                   options:[
	                   	       "A) var ",
	 	                       "B) let   ",
	 	                       "C) const ",   
	 	                       "D) Both b and c"
	 	                   ]
	                },

                    {   num:2,
	                    question:" Which variable type cannot be reassigned?",
	                    answer:"C) const",
	                    options:["A) var ",
                                 "B) let",
                                 "C) const",
                                 "D) none"]
                    },

	                {   num:3,
	                    question:"What is a closure?",
	                    answer:"B) A function that remembers its outer scope",
	                    options:["A) A self-invoking function",
                                 "B) A function that remembers its outer scope",
                                 "C) A function that runs only once",
                                 "D)  A function inside another function"]
                    },

	                {   num:4,
	                    question:" What does a function return if no return statement is given?",
	                    answer:"B) undefined",
	                    options:[
	                    	    "A) null",
                                "B) undefined",
                                "C) 0",
                                "D) false"]
	                },

	                {   num:5,
	                    question:" What does this refer to in a method inside an object?",
	                    answer:"B) The object itself",
	                    options:["A) Global object",
                                 "B) The object itself",
                                "C)  undefined",
                                "D) null"]
	                 }                    
];


console.log("question.js file loaded successfully :",questions);