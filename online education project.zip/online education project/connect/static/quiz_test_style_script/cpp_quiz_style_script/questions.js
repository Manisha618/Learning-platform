let questions=  [
                    {  num:1,
	                   question:"",
	                   answer:"",
	                   options:[
	                   	       "A)",
	 	                       "B)",
	 	                       "C)",   
	 	                       "D)"
	 	                   ]
	                },

                    {   num:2,
	                    question:"",
	                    answer:"",
	                    options:["",
                                 "",
                                 "",
                                 ""]
                    },

	                {   num:3,
	                    question:"",
	                    answer:"",
	                    options:["",
                                 "",
                                 "",
                                 ""]
                    },

	                {   num:4,
	                    question:"",
	                    answer:"",
	                    options:[
	                    	    "",
                                "",
                                "",
                                ""]
	                },

	                {   num:5,
	                    question:"",
	                    answer:"",
	                    options:["",
                                 "",
                                "",
                                ""]
	                 }                    
];


console.log("question.js file loaded successfully :",questions);