let questions=  [
                    {  num:1,
	                   question:"What is the size of an empty class in C++?",
	                   answer:"B) 1 byte",
	                   options:[
	                   	       "A) 0 bytes",
	 	                       "B) 1 byte",
	 	                       "C) Compiler dependent",   
	 	                       "D) Undefined"
	 	                   ]
	                },

                    {   num:2,
	                    question:"What is the default return type of main() in C++?",
	                    answer:"A) int",
	                    options:["A) int",
                                 "B) void",
                                 "C) float",
                                 "D) char"]
                    },

	                {   num:3,
	                    question:" Which concepts allow same name but different parameters?",
	                    answer:"",
	                    options:["A) Function Overloading",
                                 "B) Function Overriding",
                                 "C) Encapsulation",
                                 "D) Inheritance"]
                    },

	                {   num:4,
	                    question:" use of the virtual keyword in C++?",
	                    answer:"B) enables function overriding",
	                    options:[
	                    	    "A) To create a virtual class",
                                "B) enables function overriding",
                                "C) To create an instance of an abstract class",
                                "D) To make a function inline"]
	                },

	                {   num:5,
	                    question:"Which operator cannot be overloaded in C++?",
	                    answer:"C) :: (scope resolution)",
	                    options:["A) + (addition)",
                                 "B) == (is equal)",
                                "C) :: (scope resolution)",
                                "D) += (additon assignement)"]
	                 }                    
];


console.log("question.js file loaded successfully :",questions);