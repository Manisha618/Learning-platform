// function openfullscreen(){
// 	// let iframe = document.getElementsByTagName('iframe')[0];
// 	//  console.log("iframe");
// 	//   iframe.style.display = "block"; // show the iframe
// 	//   iframe.src="https://www.youtube.com/embed/GpcMasRWUhI?si=KpvZJnXiYwSm2jNm?autoplay=1&controls=1"; // src  
   
//     // let url = "https://www.youtube.com/embed/GpcMasRWUhI?si=KpvZJnXiYwSm2jNm?autoplay=1&controls=1";
//     // window.open(url, "_blank"); // open in new tag

// 	}